package com.jurimai.dao;

import com.jurimai.config.ConexionBD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JurimaiDAO {

    /*
     * CONSULTA BASE PARA OBTENER LOS DATOS DE UN LIBRO
     */
    private String consultaBaseLibros() {

        return """
            SELECT l.id_libro, l.titulo, l.ISBN, l.descripcion,
                   l.precio, l.imagen, l.fecha_publicacion, l.estado,
                   c.nombre_categoria, a.nombre_autor,
                   e.nombre_editorial,
                   COALESCE(i.cantidad_disponible, 0) AS disponibilidad,
                   0 AS unidades_vendidas
            FROM libros l
            INNER JOIN categorias c ON l.id_categoria = c.id_categoria
            INNER JOIN autores a ON l.id_autor = a.id_autor
            INNER JOIN editoriales e ON l.id_editorial = e.id_editorial
            LEFT JOIN inventario i ON l.id_libro = i.id_libro
            """;
    }

    /*
     * CONVERTIR RESULTADO EN MAPA
     */
    private Map<String, Object> crearLibro(ResultSet resultado)
            throws SQLException {

        Map<String, Object> libro = new HashMap<>();

        libro.put("id_libro", resultado.getInt("id_libro"));
        libro.put("titulo", resultado.getString("titulo"));
        libro.put("isbn", resultado.getString("ISBN"));
        libro.put("descripcion", resultado.getString("descripcion"));
        libro.put("precio", resultado.getBigDecimal("precio"));
        libro.put("imagen", resultado.getString("imagen"));
        libro.put("fecha_publicacion", resultado.getDate("fecha_publicacion"));
        libro.put("estado", resultado.getString("estado"));

        libro.put("categoria", resultado.getString("nombre_categoria"));
        libro.put("autor", resultado.getString("nombre_autor"));
        libro.put("editorial", resultado.getString("nombre_editorial"));

        libro.put("disponibilidad", resultado.getInt("disponibilidad"));
        libro.put("unidades_vendidas", resultado.getInt("unidades_vendidas"));

        return libro;
    }

    /*
     * CONSULTAR LIBROS CON LIMITE
     */
    private List<Map<String, Object>> consultarLibros(
            String sql, int limite) {

        List<Map<String, Object>> libros = new ArrayList<>();

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement consulta = conexion.prepareStatement(sql)) {

            consulta.setInt(1, limite);

            try (ResultSet resultado = consulta.executeQuery()) {

                while (resultado.next()) {
                    libros.add(crearLibro(resultado));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return libros;
    }

    /*
     * LISTAR TODOS LOS LIBROS
     */
    public List<Map<String, Object>> listarLibros() {

        List<Map<String, Object>> libros = new ArrayList<>();

        String sql = consultaBaseLibros() + """
            ORDER BY l.id_libro
            """;

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement consulta = conexion.prepareStatement(sql);
             ResultSet resultado = consulta.executeQuery()) {

            while (resultado.next()) {
                libros.add(crearLibro(resultado));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return libros;
    }

    /*
     * BUSCAR LIBROS POR TITULO, ISBN, AUTOR,
     * CATEGORIA O EDITORIAL
     */
    public List<Map<String, Object>> buscarLibros(String texto) {

        List<Map<String, Object>> libros = new ArrayList<>();

        String sql = consultaBaseLibros() + """
            WHERE l.titulo LIKE ?
               OR l.ISBN LIKE ?
               OR a.nombre_autor LIKE ?
               OR c.nombre_categoria LIKE ?
               OR e.nombre_editorial LIKE ?
            ORDER BY l.id_libro
            """;

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement consulta = conexion.prepareStatement(sql)) {

            String busqueda = "%" + texto + "%";

            for (int i = 1; i <= 5; i++) {
                consulta.setString(i, busqueda);
            }

            try (ResultSet resultado = consulta.executeQuery()) {

                while (resultado.next()) {
                    libros.add(crearLibro(resultado));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return libros;
    }

    /*
     * BUSCAR UN LIBRO POR SU ID
     */
    public Map<String, Object> buscarLibroPorId(int idLibro) {

        Map<String, Object> libro = null;

        String sql = consultaBaseLibros() + """
            WHERE l.id_libro = ?
            """;

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement consulta = conexion.prepareStatement(sql)) {

            consulta.setInt(1, idLibro);

            try (ResultSet resultado = consulta.executeQuery()) {

                if (resultado.next()) {
                    libro = crearLibro(resultado);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return libro;
    }

    /*
     * LISTAR TODAS LAS CATEGORIAS
     */
    public List<Map<String, Object>> listarCategorias() {

        List<Map<String, Object>> categorias = new ArrayList<>();

        String sql = """
            SELECT id_categoria, nombre_categoria, descripcion
            FROM categorias
            ORDER BY id_categoria
            """;

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement consulta = conexion.prepareStatement(sql);
             ResultSet resultado = consulta.executeQuery()) {

            while (resultado.next()) {

                Map<String, Object> categoria = new HashMap<>();

                categoria.put("id_categoria",
                        resultado.getInt("id_categoria"));

                categoria.put("nombre_categoria",
                        resultado.getString("nombre_categoria"));

                categoria.put("descripcion",
                        resultado.getString("descripcion"));

                categorias.add(categoria);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return categorias;
    }

    /*
     * LISTAR LIBROS POR CATEGORIA
     */
    public List<Map<String, Object>> listarLibrosPorCategoria(
            int idCategoria) {

        List<Map<String, Object>> libros = new ArrayList<>();

        String sql = consultaBaseLibros() + """
            WHERE l.id_categoria = ?
            ORDER BY l.id_libro
            """;

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement consulta = conexion.prepareStatement(sql)) {

            consulta.setInt(1, idCategoria);

            try (ResultSet resultado = consulta.executeQuery()) {

                while (resultado.next()) {
                    libros.add(crearLibro(resultado));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return libros;
    }

    /*
     * LISTAR TODAS LAS NOVEDADES
     */
    public List<Map<String, Object>> listarNovedades(int limite) {

        String sql = consultaBaseLibros() + """
            ORDER BY l.fecha_publicacion DESC
            LIMIT ?
            """;

        return consultarLibros(sql, limite);
    }

    /*
     * LISTAR LIBROS POPULARES ALEATORIOS
     */
    public List<Map<String, Object>> listarPopulares(int limite) {

        String sql = consultaBaseLibros() + """
            ORDER BY RAND()
            LIMIT ?
            """;

        return consultarLibros(sql, limite);
    }

    /*
     * LISTAR TOP DE JURIMAI ALEATORIO
     */
    public List<Map<String, Object>> listarTopLibros(int limite) {

        String sql = consultaBaseLibros() + """
            ORDER BY RAND()
            LIMIT ?
            """;

        return consultarLibros(sql, limite);
    }

    /*
     * LISTAR LIBROS DESTACADOS ALEATORIOS
     */
    public List<Map<String, Object>> listarDestacados(int limite) {

        String sql = consultaBaseLibros() + """
            WHERE l.destacado = 1
            ORDER BY RAND()
            LIMIT ?
            """;

        return consultarLibros(sql, limite);
    }

    /*
     * LISTAR LIBROS RECOMENDADOS ALEATORIOS
     */
    public List<Map<String, Object>> listarRecomendados(int limite) {

        String sql = consultaBaseLibros() + """
            ORDER BY RAND()
            LIMIT ?
            """;

        return consultarLibros(sql, limite);
    }

    /*
     * LISTAR DESCUENTOS ACTIVOS
     */
    public List<Map<String, Object>> listarOfertas() {

        List<Map<String, Object>> ofertas = new ArrayList<>();

        String sql = """
            SELECT id_descuento, nombre, codigo_cupon,
                   tipo_descuento, valor_descuento,
                   fecha_inicio, fecha_fin,
                   cantidad_maxima, estado
            FROM descuentos
            WHERE estado = 'Activo'
              AND (fecha_inicio IS NULL OR fecha_inicio <= NOW())
              AND (fecha_fin IS NULL OR fecha_fin >= NOW())
            ORDER BY id_descuento
            """;

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement consulta = conexion.prepareStatement(sql);
             ResultSet resultado = consulta.executeQuery()) {

            while (resultado.next()) {

                Map<String, Object> descuento = new HashMap<>();

                descuento.put("id_descuento",
                        resultado.getInt("id_descuento"));

                descuento.put("nombre",
                        resultado.getString("nombre"));

                descuento.put("codigo_cupon",
                        resultado.getString("codigo_cupon"));

                descuento.put("tipo_descuento",
                        resultado.getString("tipo_descuento"));

                descuento.put("valor_descuento",
                        resultado.getBigDecimal("valor_descuento"));

                descuento.put("fecha_inicio",
                        resultado.getTimestamp("fecha_inicio"));

                descuento.put("fecha_fin",
                        resultado.getTimestamp("fecha_fin"));

                descuento.put("cantidad_maxima",
                        resultado.getInt("cantidad_maxima"));

                descuento.put("estado",
                        resultado.getString("estado"));

                ofertas.add(descuento);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return ofertas;
    }

}