package com.jurimai.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.jurimai.dao.JurimaiDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/inicio")
public class JurimaiServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        JurimaiDAO dao = new JurimaiDAO();

        List<Map<String, Object>> libros = dao.listarLibros();
        List<Map<String, Object>> categorias = dao.listarCategorias();

        request.setAttribute("libros", libros);
        request.setAttribute("categorias", categorias);
        request.setAttribute("novedades", dao.listarNovedades(8));
        request.setAttribute("destacados", dao.listarDestacados(8));
        request.setAttribute("populares", dao.listarPopulares(8));
        request.setAttribute("topLibros", dao.listarTopLibros(8));
        request.getRequestDispatcher("/WEB-INF/vistas/index.jsp")
               .forward(request, response);
    }
}