package com.jurimai.controller;

import java.io.IOException;
import java.util.Map;

import com.jurimai.dao.JurimaiDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/libro")
public class LibroServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id");

        try {
            int idLibro = Integer.parseInt(id);

            JurimaiDAO dao = new JurimaiDAO();

            Map<String, Object> libro = dao.buscarLibroPorId(idLibro);

            if (libro == null) {
                response.sendError(404, "Libro no encontrado");
                return;
            }

            request.setAttribute("libro", libro);

            request.getRequestDispatcher("/WEB-INF/vistas/detalle.jsp")
                   .forward(request, response);

        } catch (NumberFormatException ex) {
            response.sendError(400, "Identificador de libro inválido");
        }
    }
}