package com.jurimai.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.jurimai.dao.JurimaiDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/categoria")
public class CategoriaServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        String id = request.getParameter("id");

        try {
            int idCategoria = Integer.parseInt(id);

            JurimaiDAO dao = new JurimaiDAO();

            List<Map<String, Object>> libros =
                    dao.listarLibrosPorCategoria(idCategoria);

            List<Map<String, Object>> categorias =
                    dao.listarCategorias();

            request.setAttribute("libros", libros);
            request.setAttribute("categorias", categorias);
            request.setAttribute("idCategoria", idCategoria);

            request.getRequestDispatcher("/WEB-INF/vistas/categoria.jsp")
                   .forward(request, response);

        } catch (NumberFormatException ex) {
            response.sendError(400, "Identificador de categoría inválido");
        }
    }
}