package com.jurimai.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.jurimai.dao.JurimaiDAO;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/buscar")
public class BusquedaServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        String texto = request.getParameter("texto");

        if (texto == null) {
            texto = "";
        }

        JurimaiDAO dao = new JurimaiDAO();

        List<Map<String, Object>> libros = dao.buscarLibros(texto);

        request.setAttribute("libros", libros);
        request.setAttribute("texto", texto);

        request.getRequestDispatcher("/WEB-INF/vistas/busqueda.jsp")
               .forward(request, response);
    }
}