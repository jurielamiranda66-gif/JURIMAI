package com.jurimai.model;

import java.time.LocalDate;
import java.math.BigDecimal;

public class Descuentos {
	private int idDescuento;
	private String nombre;
	private String codigoCupon;
	private String tipoDescuento;
	private BigDecimal valorDescuento;
	private LocalDate fechaInicio;
	private LocalDate fechaFin;
	private int cantidadMaxima;
	private String estado = "Activo";
	
	public Descuentos(int idDescuento, String nombre, String codigoCupon, String tipoDescuento, BigDecimal valorDescuento, LocalDate fechaInicio, LocalDate fechaFin, int cantidadMaxima, String estado) {
		this.idDescuento = idDescuento;
		this.nombre = nombre;
		this.codigoCupon = codigoCupon;
		this.tipoDescuento = tipoDescuento;
		this.valorDescuento = valorDescuento;
		this.fechaInicio = fechaInicio;
		this.fechaFin = fechaFin;
		this.cantidadMaxima = cantidadMaxima;
		this.estado = estado;
	}

	public int getIdDescuento() {
        return idDescuento;
    }

    public void setIdDescuento(int idDescuento) {
        this.idDescuento = idDescuento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCodigoCupon() {
        return codigoCupon;
    }

    public void setCodigoCupon(String codigoCupon) {
        this.codigoCupon = codigoCupon;
    }

    public String getTipoDescuento() {
        return tipoDescuento;
    }

    public void setTipoDescuento(String tipoDescuento) {
        this.tipoDescuento = tipoDescuento;
    }

    public BigDecimal getValorDescuento() {
        return valorDescuento;
    }

    public void setValorDescuento(BigDecimal valorDescuento) {
        this.valorDescuento = valorDescuento;
    }

    public LocalDate getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(LocalDate fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public LocalDate getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(LocalDate fechaFin) {
        this.fechaFin = fechaFin;
    }

    public int getCantidadMaxima() {
        return cantidadMaxima;
    }

    public void setCantidadMaxima(int cantidadMaxima) {
        this.cantidadMaxima = cantidadMaxima;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "ID del descuento: " + idDescuento
                + "\nNombre: " + nombre
                + "\nCódigo del cupón: " + codigoCupon
                + "\nTipo de descuento: " + tipoDescuento
                + "\nValor del descuento: " + valorDescuento
                + "\nFecha de inicio: " + fechaInicio
                + "\nFecha de fin: " + fechaFin
                + "\nCantidad máxima: " + cantidadMaxima
                + "\nEstado: " + estado;
    }
}
