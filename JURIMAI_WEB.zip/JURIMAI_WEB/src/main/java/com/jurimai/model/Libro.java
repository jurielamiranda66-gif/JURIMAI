package com.jurimai.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Libro {
	private int idLibro;
	private final int idCategoria;
	private final int idAutor;
	private final int idEditorial;
	private String titulo;
	private String isbn;
	private String descripcion;
	private BigDecimal precio;
	private String imagen;
	private LocalDate fechaPublicacion;
	private String estado = "Disponible";
	
	public Libro(int idLibro, int idCategoria, int idAutor, int idEditorial, String titulo,  String isbn, String descripcion, BigDecimal precio, String imagen, LocalDate fechaPublicacion, String estado) {
		this.idLibro = idLibro;
		this.idCategoria = idCategoria;
		this.idAutor = idAutor;
		this.idEditorial = idEditorial;
		this.titulo = titulo;
		this.isbn = isbn;
		this.descripcion = descripcion;
		this.precio = precio;
		this.imagen = imagen;
		this.fechaPublicacion = fechaPublicacion;
		this.estado = estado;
	}
	
	public int getIdLibro() {
		return idLibro;
	}
	
	public int getIdCategoria() {
		return idCategoria;
	}
	
	public int getIdAutor() {
		return idAutor;
	}
	
	public int getIdEditorial() {
		return idEditorial;
	}
	
	public String getTitulo() {
		return titulo;
	}
	
	public String getIsbn() {
		return isbn;
	}
	
	public String getDescripcion() {
		return descripcion;
	}
	
	public BigDecimal getPrecio() {
		return precio;
	}
	
	public void setPrecio(BigDecimal precio) {
		this.precio = precio;
	}

	public String getImagen() {
	    return imagen;
	}

	public void setImagen(String imagen) {
	    this.imagen = imagen;
	}
	
	public LocalDate getFechaPublicacion() {
		return fechaPublicacion;
	}
	
	public String getEstado() {
	    return estado;
	}

	public void setEstado(String estado) {
	    this.estado = estado;
	}
	
	@Override
	public String toString() {
		return "ID del Libro: " + idLibro
				+ "\nID de la categoria: " + idCategoria
				+ "\nID del autor: " + idAutor
				+ "\nID de la editorial: " + idEditorial
				+ "\nTitulo del libro: " + titulo
				+ "\nISBN: " + isbn
				+ "\nDescripción del libro: " + descripcion
				+ "\nPrecio: " + precio
				+ "\nImagen: " + imagen
				+ "\nFecha de publicación: " + fechaPublicacion
				+ "\nEstado: " + estado;
	}
}
