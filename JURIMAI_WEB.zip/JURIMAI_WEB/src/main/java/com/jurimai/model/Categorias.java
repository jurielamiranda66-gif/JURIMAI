package com.jurimai.model;

public class Categorias {
	private int idCategoria;
	private String nombreCategoria;
	private String descripcion;
	
	public Categorias(int idCategoria, String nombreCategoria, String descripcion) {
		this.idCategoria = idCategoria;
		this.nombreCategoria = nombreCategoria;
		this.descripcion = descripcion;
	}
	
	public int getIdCategoria() {
		return idCategoria;
	}
	
	public String getNombreCategoria() {
		return nombreCategoria;
	}
	
	public String getDescripcion() {
		return descripcion;
	}
	
	@Override
	public String toString() {
		return "ID de la categoría: " + idCategoria
				+ "\nNombre de la categoría: " + nombreCategoria
				+ "\nDescripción: " + descripcion;
	}
}
