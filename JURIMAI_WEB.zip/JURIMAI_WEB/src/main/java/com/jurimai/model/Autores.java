package com.jurimai.model;

public class Autores {
	private int idAutor;
	private String nombreAutor;
	private String biografia;
    private String nacionalidad;
    
    public Autores(int idAutor, String nombreAutor, String biografia, String nacionalidad) {
    	this.idAutor = idAutor;
    	this.nombreAutor = nombreAutor;
    	this.biografia = biografia;
    	this.nacionalidad = nacionalidad;
    }
    
    public int getIdAutor() {
		return idAutor;
	}
	
	public String getNombreAutor() {
		return nombreAutor;
	}
	
	public String getBiografia() {
		return biografia;
	}
	
	public String getNacionalidad() {
		return nacionalidad;
	}
	
	@Override
	public String toString() {
		return "ID del autor: " + idAutor
				+ "\nNombre del autor: " + nombreAutor
				+ "\nBiografía: " + biografia
				+ "\nNacionalidad: " + nacionalidad;
	}
}
