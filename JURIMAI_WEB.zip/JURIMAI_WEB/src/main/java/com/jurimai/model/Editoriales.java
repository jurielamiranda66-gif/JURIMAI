package com.jurimai.model;

public class Editoriales {
	private int idEditorial;
	private String nombreEditorial;
	private String pais;
	private String telefono;
	private String correo;
	private String sitioWeb;
	private String direccion;
	
	public Editoriales(int idEditorial, String nombreEditorial, String pais, String telefono, String correo, String sitioWeb, String direccion) {
		this.idEditorial = idEditorial;
		this.nombreEditorial = nombreEditorial;
		this.pais = pais;
		this.telefono = telefono;
		this.correo = correo;
		this.sitioWeb = sitioWeb;
		this.direccion = direccion;
	}
	
	 public int getIdEditorial() {
			return idEditorial;
		}
		
		public String getNombreEditorial() {
			return nombreEditorial;
		}
		
		public String getPais() {
			return pais;
		}
		
		public String getTelefono() {
			return telefono;
		}
		
		public String getCorreo() {
			return correo;
		}
		
		public String getSitioWeb() {
			return sitioWeb;
		}
		
		public String getDireccion() {
			return direccion;
		}	
		
		@Override
		public String toString() {
			return "ID de la editorial: " + idEditorial
					+ "\nNombre de la editorial: " + nombreEditorial
					+ "\nPais: " + pais
					+ "\nTelefono: " + telefono
					+ "\nCorreo: " + correo
					+ "\nSitio Web: " + sitioWeb
					+ "\nDirección: " + direccion;
		}
}
