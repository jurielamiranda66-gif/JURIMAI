package com.jurimai.model;

import java.time.LocalDate;

public class Inventario {
	private int idInventario;
	private final int idLibro;
	private int cantidadDisponible;
	private int stockMinimo;
	private LocalDate fechaActualizacion;
	
	public Inventario(int idInventario, int idLibro, int cantidadDisponible, int stockMinimo, LocalDate fechaActualizacion) {
		this.idInventario = idInventario;
		this.idLibro = idLibro;
		this.cantidadDisponible = cantidadDisponible;
		this.stockMinimo = stockMinimo;
		this.fechaActualizacion = fechaActualizacion;
	}
	
	 public int getIdInventario() {
	        return idInventario;
	    }

	    public void setIdInventario(int idInventario) {
	        this.idInventario = idInventario;
	    }

	    public int getIdLibro() {
	        return idLibro;
	    }

	    public int getCantidadDisponible() {
	        return cantidadDisponible;
	    }

	    public void setCantidadDisponible(int cantidadDisponible) {
	        this.cantidadDisponible = cantidadDisponible;
	    }

	    public int getStockMinimo() {
	        return stockMinimo;
	    }

	    public void setStockMinimo(int stockMinimo) {
	        this.stockMinimo = stockMinimo;
	    }

	    public LocalDate getFechaActualizacion() {
	        return fechaActualizacion;
	    }

	    public void setFechaActualizacion(LocalDate fechaActualizacion) {
	        this.fechaActualizacion = fechaActualizacion;
	    }

	    public boolean verificarStock() {
	        return cantidadDisponible <= stockMinimo;
	    }

	    @Override
	    public String toString() {
	        return "ID del inventario: " + idInventario
	                + "\nID del libro: " + idLibro
	                + "\nCantidad disponible: " + cantidadDisponible
	                + "\nStock mínimo: " + stockMinimo
	                + "\nFecha de actualización: " + fechaActualizacion;
	    }
	}