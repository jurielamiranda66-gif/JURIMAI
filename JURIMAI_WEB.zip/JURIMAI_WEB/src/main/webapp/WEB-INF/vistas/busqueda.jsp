<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>JURIMAI | Resultados de búsqueda</title>

    <link rel="stylesheet"
          href="${pageContext.request.contextPath}/css/estilos.css">

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>

<body>

    <!-- ====================================== -->
    <!-- 1. ENCABEZADO -->
    <!-- ====================================== -->

    <header class="catalogo-encabezado">

        <div class="catalogo-marca">
            <i class="fa-solid fa-book-open"></i>
            <h1>JURIMAI</h1>
        </div>

        <p>Un sueño que florece, un recuerdo que vive para siempre.</p>

        <!-- BUSCADOR -->

        <form action="${pageContext.request.contextPath}/buscar"
              method="get"
              class="buscador">

            <input type="text"
                   name="texto"
                   value="<%= request.getAttribute("texto") == null ? "" : request.getAttribute("texto") %>"
                   placeholder="Buscar por título, autor, editorial o género...">

            <button type="submit">
                <i class="fa-solid fa-magnifying-glass"></i>
                Buscar
            </button>

        </form>

    </header>


    <!-- ====================================== -->
    <!-- 2. RESULTADOS -->
    <!-- ====================================== -->

    <main class="catalogo-contenedor">

        <section class="seccion-libros">

            <div class="catalogo-titulo">

                <span>ENCUENTRA TU PRÓXIMA LECTURA</span>

                <h2>Resultados de búsqueda</h2>

                <p>
                    Estos son los libros relacionados con tu búsqueda.
                </p>

            </div>

            <div class="libros-grid">

                <%

                    List<Map<String, Object>> libros =
                        (List<Map<String, Object>>) request.getAttribute("libros");

                    if (libros != null && !libros.isEmpty()) {

                        for (Map<String, Object> libro : libros) {

                %>

                    <article class="libro-tarjeta">

                        <!-- PORTADA -->

                        <div class="libro-portada">

                            <img src="<%= libro.get("imagen") %>"
                                 alt="Portada de <%= libro.get("titulo") %>"
                                 onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">

                            <div class="portada-error">

                                <i class="fa-solid fa-book"></i>

                                <span>Portada no disponible</span>

                            </div>

                        </div>

                        <!-- INFORMACIÓN -->

                        <div class="libro-informacion">

                            <h3><%= libro.get("titulo") %></h3>

                            <p>
                                <i class="fa-regular fa-user"></i>
                                <%= libro.get("autor") %>
                            </p>

                            <div class="libro-precio">
                                ₡<%= libro.get("precio") %>
                            </div>

                            <a href="${pageContext.request.contextPath}/libro?id=<%= libro.get("id_libro") %>"
                               class="btn-libro">

                                Ver detalles
                                <i class="fa-solid fa-arrow-right"></i>

                            </a>

                        </div>

                    </article>

                <%

                        }

                    } else {

                %>

                    <div class="catalogo-vacio">

                        <i class="fa-solid fa-book-open"></i>

                        <h3>No se encontraron libros</h3>

                        <p>
                            Intenta buscar con otro título, autor o categoría.
                        </p>

                    </div>

                <%

                    }

                %>

            </div>

        </section>

        <!-- VOLVER AL CATÁLOGO -->

        <div style="text-align: center; margin-top: 40px;">

            <a href="${pageContext.request.contextPath}/inicio"
               class="btn-principal">

                <i class="fa-solid fa-arrow-left"></i>
                Volver al catálogo

            </a>

        </div>

    </main>


    <!-- ====================================== -->
    <!-- 3. PIE DE PÁGINA -->
    <!-- ====================================== -->

    <footer class="catalogo-pie">

        <h2>JURIMAI</h2>

        <p>Un sueño que florece, un recuerdo que vive para siempre.</p>

        <span>&copy; 2026 JURIMAI. Todos los derechos reservados.</span>

    </footer>

</body>
</html>