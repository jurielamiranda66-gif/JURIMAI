<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ page import="java.util.Map"%>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>JURIMAI | Detalles del libro</title>

    <link rel="stylesheet"
        href="${pageContext.request.contextPath}/css/estilos.css">

    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

</head>

<body>

    <!-- 1. ENCABEZADO -->

    <header class="catalogo-encabezado">

        <div class="catalogo-marca">

            <i class="fa-solid fa-book-open"></i>

            <h1>JURIMAI</h1>

        </div>

        <p>Un sueño que florece, un recuerdo que vive para siempre.</p>

    </header>


    <!-- 2. INFORMACIÓN DEL LIBRO -->

    <main class="detalle-contenedor">

        <%

            Map<String, Object> libro =
                (Map<String, Object>) request.getAttribute("libro");

            if (libro != null) {

        %>

            <div class="detalle-ruta">

                <a href="${pageContext.request.contextPath}/inicio">
                    Inicio
                </a>

                <i class="fa-solid fa-chevron-right"></i>

                <span>Detalles del libro</span>

            </div>


            <section class="detalle-libro">

                <!-- PORTADA -->

                <div class="detalle-portada">

                    <img
                        src="${pageContext.request.contextPath}/<%= String.valueOf(libro.get("imagen")).replaceFirst("^/+", "") %>"
                        alt="Portada de <%= libro.get("titulo") %>"
                        onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">

                    <div class="detalle-portada-error">

                        <i class="fa-solid fa-book-open"></i>

                        <span>Portada no disponible</span>

                    </div>

                </div>


                <!-- DATOS DEL LIBRO -->

                <div class="detalle-informacion">

                    <span class="detalle-etiqueta">
                        JURIMAI | FICHA DEL LIBRO
                    </span>

                    <h2><%= libro.get("titulo") %></h2>

                    <p class="detalle-autor">

                        <i class="fa-regular fa-user"></i>

                        <%= libro.get("autor") %>

                    </p>


                    <!-- PRECIO -->

                    <div class="detalle-precio">

                        <span>Precio</span>

                        <h3>
                            ₡<%= libro.get("precio") %>
                        </h3>

                    </div>


                    <!-- DISPONIBILIDAD -->

                    <div class="detalle-disponibilidad">

                        <i class="fa-solid fa-box"></i>

                        <span>

                            Disponibilidad:

                            <strong><%= libro.get("disponibilidad") %></strong>

                        </span>

                    </div>


                    <!-- DESCRIPCIÓN -->

                    <div class="detalle-descripcion">

                        <h3>Sinopsis y descripción</h3>

                        <p>
                            <%= libro.get("descripcion") %>
                        </p>

                    </div>


                    <!-- INFORMACIÓN ADICIONAL -->

                    <div class="detalle-datos">

                        <h3>Información del libro</h3>

                        <p>

                            <strong>Editorial:</strong>

                            <%= libro.get("editorial") %>

                        </p>

                        <p>

                            <strong>Categoría:</strong>

                            <%= libro.get("categoria") %>

                        </p>

                        <p>

                            <strong>ISBN:</strong>

                            <%= libro.get("ISBN") %>

                        </p>

                    </div>


                    <!-- BOTÓN DE REGRESO -->

                    <a href="${pageContext.request.contextPath}/inicio"
                       class="btn-libro-volver">

                        <i class="fa-solid fa-arrow-left"></i>

                        Volver al catálogo

                    </a>

                </div>

            </section>

        <%

            } else {

        %>

            <div class="detalle-no-encontrado">

                <i class="fa-solid fa-book"></i>

                <h2>Libro no encontrado</h2>

                <p>No encontramos la información de este libro.</p>

                <a href="${pageContext.request.contextPath}/inicio"
                   class="btn-principal">

                    Volver al catálogo

                </a>

            </div>

        <%

            }

        %>

    </main>


    <!-- 3. PIE DE PÁGINA -->

    <footer class="catalogo-pie">

        <h2>JURIMAI</h2>

        <p>Un sueño que florece, un recuerdo que vive para siempre.</p>

        <span>&copy; 2026 JURIMAI. Todos los derechos reservados.</span>

    </footer>

</body>

</html>