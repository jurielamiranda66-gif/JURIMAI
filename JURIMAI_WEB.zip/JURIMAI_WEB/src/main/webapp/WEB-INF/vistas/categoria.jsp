<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>

<%@ page import="java.util.List"%>
<%@ page import="java.util.Map"%>

<!DOCTYPE html>
<html lang="es">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>JURIMAI | Categorías</title>

<link rel="stylesheet"
	href="${pageContext.request.contextPath}/css/estilos.css">

<link rel="stylesheet"
	href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>

<body>

	<!-- ENCABEZADO -->

	<header class="catalogo-encabezado">

		<div class="catalogo-marca">
			<a href="${pageContext.request.contextPath}/inicio"> <i
				class="fas fa-book-open"></i> <span>JURIMAI</span>
			</a>
		</div>

		<form class="buscador"
			action="${pageContext.request.contextPath}/buscar" method="get">

			<input type="text" name="texto"
				placeholder="Buscar libros, autores o editoriales...">

			<button type="submit">
				<i class="fas fa-search"></i>
			</button>

		</form>

		<div class="catalogo-acciones">

			<a href="${pageContext.request.contextPath}/inicio"> <i
				class="far fa-heart"></i>
			</a> <a href="${pageContext.request.contextPath}/inicio"> <i
				class="fas fa-shopping-cart"></i>
			</a>

		</div>

	</header>


	<!-- CONTENIDO PRINCIPAL -->

	<main class="catalogo-contenedor">

		<div class="catalogo-titulo">

			<span class="catalogo-etiqueta"> EXPLORA JURIMAI </span>

			<%
			List<Map<String, Object>> categorias = (List<Map<String, Object>>) request.getAttribute("categorias");

			Object idSeleccionado = request.getAttribute("idCategoria");
			String nombreCategoria = "Libros por categoría";

			if (categorias != null && idSeleccionado != null) {

				for (Map<String, Object> categoria : categorias) {

					if (String.valueOf(categoria.get("id_categoria")).equals(String.valueOf(idSeleccionado))) {

				nombreCategoria = String.valueOf(categoria.get("nombre_categoria"));
				break;
					}
				}
			}
			%>

			<h1><%=nombreCategoria%></h1>

			<p>Descubre nuevas historias y encuentra tus próximas lecturas.</p>

		</div>


		<!-- CATÁLOGO DE LIBROS -->

		<section class="libros-grid">

			<%
			List<Map<String, Object>> libros = (List<Map<String, Object>>) request.getAttribute("libros");

			if (libros != null && !libros.isEmpty()) {

				for (Map<String, Object> libro : libros) {
			%>

			<article class="libro-tarjeta">

				<a
					href="${pageContext.request.contextPath}/libro?id=<%= libro.get("id_libro") %>">

					<div class="libro-portada">

						<img
							src="${pageContext.request.contextPath}/<%= libro.get("imagen") %>"
							alt="<%= libro.get("titulo") %>"
							onerror="this.style.display='none'; this.parentElement.classList.add('portada-error');">

					</div>

				</a>


				<div class="libro-informacion">

					<h3>
						<%=libro.get("titulo")%>
					</h3>

					<p class="libro-autor">
						<%=libro.get("autor")%>
					</p>

					<p class="libro-precio">
						₡<%=libro.get("precio")%>
					</p>

					<a class="btn-libro"
						href="${pageContext.request.contextPath}/libro?id=<%= libro.get("id_libro") %>">

						Ver detalles </a>

				</div>

			</article>

			<%
			}

			} else {
			%>

			<div class="catalogo-vacio">

				<i class="fas fa-book-open"></i>

				<h2>No hay libros disponibles</h2>

				<p>Actualmente no hay libros registrados en esta categoría.</p>

			</div>

			<%
			}
			%>

		</section>


		<!-- BOTÓN REGRESAR -->

		<div class="catalogo-regresar">

			<a href="${pageContext.request.contextPath}/inicio"> <i
				class="fas fa-arrow-left"></i> Volver al inicio

			</a>

		</div>

	</main>


	<!-- PIE DE PÁGINA -->

	<footer class="catalogo-pie">

		<p>&copy; 2026 JURIMAI. Todos los derechos reservados.</p>

		<p>Un sueño que florece, un recuerdo que vive para siempre.</p>

	</footer>


	<script src="${pageContext.request.contextPath}/js/funciones.js"></script>

</body>

</html>